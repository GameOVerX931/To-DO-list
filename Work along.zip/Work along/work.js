// Select DOM elements
const taskInput = document.getElementById('task-input');
const prioritySelect = document.getElementById('priority-select');
const addTaskButton = document.getElementById('add-task-button');
const taskList = document.getElementById('task-list');
const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const sortButton = document.getElementById('sort-button');

let sortOrder = 'asc'; // Sort order: 'asc' for A-Z, 'desc' for Z-A

// Add event listeners
addTaskButton.addEventListener('click', addTask);
searchButton.addEventListener('click', filterTasks);
searchInput.addEventListener('keyup', filterTasks); // Filter tasks while typing
sortButton.addEventListener('click', sortTasks);

// Add event listener for 'Enter' key press in task input field
taskInput.addEventListener('keydown', function(event) {
  if (event.key === 'Enter') {
    addTask(); // Call addTask function when 'Enter' is pressed
  }
});

// Function to add task
function addTask() {
  const taskText = taskInput.value.trim();
  const priority = prioritySelect.value; // Get selected priority

  if (taskText === '') return;

  const li = document.createElement('li');
  li.innerHTML = `${taskText} <button class="delete-button">Delete</button>`;

  // Add priority class
  li.classList.add(priority === 'high' ? 'high-priority' : 'low-priority');

  // Append the task to the list
  taskList.appendChild(li);
  taskInput.value = ''; // Clear input field after adding the task

  // Mark task as completed when clicked
  li.addEventListener('click', function () {
    li.classList.toggle('completed');
  });

  // Delete task when the delete button is clicked
  li.querySelector('.delete-button').addEventListener('click', function (event) {
    event.stopPropagation(); // Prevent task completion toggle on delete click
    taskList.removeChild(li);
  });
}

// Function to filter tasks based on search input
function filterTasks() {
  const searchText = searchInput.value.toLowerCase();
  const tasks = document.querySelectorAll('li');

  tasks.forEach(task => {
    const taskText = task.firstChild.textContent.toLowerCase();
    if (taskText.includes(searchText)) {
      task.style.display = '';
    } else {
      task.style.display = 'none';
    }
  });
}

// Function to sort tasks alphabetically (A-Z or Z-A)
function sortTasks() {
  const tasks = Array.from(taskList.querySelectorAll('li'));

  tasks.sort((a, b) => {
    const taskA = a.firstChild.textContent.toLowerCase();
    const taskB = b.firstChild.textContent.toLowerCase();
    
    if (sortOrder === 'asc') {
      return taskA.localeCompare(taskB); // A-Z
    } else {
      return taskB.localeCompare(taskA); // Z-A
    }
  });

  // Clear the list and append sorted tasks
  taskList.innerHTML = '';
  tasks.forEach(task => taskList.appendChild(task));

  // Toggle sort order and update button text
  if (sortOrder === 'asc') {
    sortOrder = 'desc';
    sortButton.textContent = 'Sort Z-A';
  } else {
    sortOrder = 'asc';
    sortButton.textContent = 'Sort A-Z';
  }
}

